This should make things easier
